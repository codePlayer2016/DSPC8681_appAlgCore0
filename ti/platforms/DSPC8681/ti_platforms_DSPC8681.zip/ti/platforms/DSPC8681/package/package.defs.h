/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-z52
 */

#ifndef ti_platforms_DSPC8681__
#define ti_platforms_DSPC8681__



#endif /* ti_platforms_DSPC8681__ */ 
